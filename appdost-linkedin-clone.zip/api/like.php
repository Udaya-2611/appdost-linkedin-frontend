<?php
require 'db.php';
require '_utils.php';
$data = body();
$user = require_auth($pdo);
$post_id = intval($data['post_id'] ?? 0);
if(!$post_id) send(['success'=>false,'error'=>'Missing post id']);
try{
  // check if already liked
  $stmt = $pdo->prepare('SELECT id FROM likes WHERE post_id = ? AND user_id = ? LIMIT 1');
  $stmt->execute([$post_id, $user['id']]);
  if($stmt->fetch()){
    // unlike (toggle)
    $stmt = $pdo->prepare('DELETE FROM likes WHERE post_id = ? AND user_id = ?');
    $stmt->execute([$post_id, $user['id']]);
  } else {
    $stmt = $pdo->prepare('INSERT INTO likes (post_id,user_id,created_at) VALUES (?,?,NOW())');
    $stmt->execute([$post_id, $user['id']]);
  }
  // return new like count
  $stmt = $pdo->prepare('SELECT COUNT(1) as c FROM likes WHERE post_id = ?');
  $stmt->execute([$post_id]);
  $c = $stmt->fetch()['c'] ?? 0;
  send(['success'=>true,'likes'=>intval($c)]);
} catch(Exception $e){ send(['success'=>false,'error'=>$e->getMessage()]); }
?>