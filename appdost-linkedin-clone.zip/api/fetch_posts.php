<?php
require 'db.php';
require '_utils.php';
try{
  $stmt = $pdo->query('SELECT p.id,p.user_id,p.content,p.created_at, u.name, (SELECT COUNT(1) FROM likes l WHERE l.post_id = p.id) as likes FROM posts p JOIN users u ON u.id = p.user_id ORDER BY p.created_at DESC');
  $posts = $stmt->fetchAll();
  // format created_at friendly
  foreach($posts as &$p){ $p['created_at'] = date('Y-m-d H:i', strtotime($p['created_at'])); }
  send(['success'=>true,'posts'=>$posts]);
} catch(Exception $e){ send(['success'=>false,'error'=>$e->getMessage()]); }
?>