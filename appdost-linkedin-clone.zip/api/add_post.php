<?php
require 'db.php';
require '_utils.php';
$data = body();
$user = require_auth($pdo);
$content = trim($data['content'] ?? '');
if(!$content) send(['success'=>false,'error'=>'Empty content']);
try{
  $stmt = $pdo->prepare('INSERT INTO posts (user_id,content,created_at) VALUES (?,?,NOW())');
  $stmt->execute([$user['id'],$content]);
  send(['success'=>true,'post_id'=>$pdo->lastInsertId()]);
} catch(Exception $e){ send(['success'=>false,'error'=>$e->getMessage()]); }
?>