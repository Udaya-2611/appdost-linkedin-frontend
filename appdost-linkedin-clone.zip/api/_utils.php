<?php
// utils - common helpers
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
// read JSON body
function body(){ $raw = file_get_contents('php://input'); return json_decode($raw,true) ?: []; }
function send($arr){ echo json_encode($arr); exit; }
function require_auth($pdo){
  $headers = getallheaders();
  $token = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($headers['authorization']) ? $headers['authorization'] : '');
  if(!$token) send(['success'=>false,'error'=>'Unauthorized']);
  $stmt = $pdo->prepare('SELECT id,name,email FROM users WHERE token = ? LIMIT 1');
  $stmt->execute([$token]);
  $user = $stmt->fetch();
  if(!$user) send(['success'=>false,'error'=>'Invalid token']);
  return $user;
}
?>