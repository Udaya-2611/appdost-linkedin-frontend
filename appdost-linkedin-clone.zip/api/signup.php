<?php
require 'db.php';
require '_utils.php';
$data = body();
$name = trim($data['name'] ?? '');
$email = strtolower(trim($data['email'] ?? ''));
$pass = $data['password'] ?? '';
if(!$name || !$email || !$pass) send(['success'=>false,'error'=>'Missing fields']);
try{
  // check exists
  $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
  $stmt->execute([$email]);
  if($stmt->fetch()) send(['success'=>false,'error'=>'Email already registered']);
  $hash = password_hash($pass, PASSWORD_DEFAULT);
  $token = bin2hex(random_bytes(16));
  $stmt = $pdo->prepare('INSERT INTO users (name,email,password_hash,token,created_at) VALUES (?,?,?,?,NOW())');
  $stmt->execute([$name,$email,$hash,$token]);
  $user_id = $pdo->lastInsertId();
  send(['success'=>true,'user_id'=>$user_id,'token'=>$token]);
} catch(Exception $e){ send(['success'=>false,'error'=>$e->getMessage()]); }
?>