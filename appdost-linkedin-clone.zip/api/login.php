<?php
require 'db.php';
require '_utils.php';
$data = body();
$email = strtolower(trim($data['email'] ?? ''));
$pass = $data['password'] ?? '';
if(!$email || !$pass) send(['success'=>false,'error'=>'Missing fields']);
try{
  $stmt = $pdo->prepare('SELECT id,name,password_hash FROM users WHERE email = ? LIMIT 1');
  $stmt->execute([$email]);
  $u = $stmt->fetch();
  if(!$u || !password_verify($pass, $u['password_hash'])) send(['success'=>false,'error'=>'Invalid credentials']);
  // rotate token
  $token = bin2hex(random_bytes(16));
  $stmt = $pdo->prepare('UPDATE users SET token = ? WHERE id = ?');
  $stmt->execute([$token, $u['id']]);
  send(['success'=>true,'user_id'=>$u['id'],'name'=>$u['name'],'email'=>$email,'token'=>$token]);
} catch(Exception $e){ send(['success'=>false,'error'=>$e->getMessage()]); }
?>