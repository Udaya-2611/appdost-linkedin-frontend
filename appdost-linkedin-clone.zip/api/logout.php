<?php
require 'db.php';
require '_utils.php';
$user = require_auth($pdo);
try{
  $stmt = $pdo->prepare('UPDATE users SET token = NULL WHERE id = ?');
  $stmt->execute([$user['id']]);
  send(['success'=>true]);
} catch(Exception $e){ send(['success'=>false,'error'=>$e->getMessage()]); }
?>